{if(!defined("RUN_MODE"))} {!die()} {/if}
<nav data-ve='block' data-id='{!echo $block->id}' class='usermenu'>
  <span id='userMenu'></span>
  <?php commonModel::printLanguageBar()}
</nav>

