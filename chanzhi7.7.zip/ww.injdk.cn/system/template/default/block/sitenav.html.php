{if(!defined("RUN_MODE"))} {!die()} {/if}
<nav id='siteNav'>{$config->siteNavHolder}</nav> 
