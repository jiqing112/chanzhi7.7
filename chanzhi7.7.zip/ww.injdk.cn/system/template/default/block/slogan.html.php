{if(!defined("RUN_MODE"))} {!die()} {/if}
<div class='site-slogan' data-ve='block' data-id='{!echo $block->id}'><div data-ve='slogan'>{!echo $lang->site->slogan}</div></div>
