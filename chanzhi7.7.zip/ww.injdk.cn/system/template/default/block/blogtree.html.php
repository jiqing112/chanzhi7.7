{if(!defined("RUN_MODE"))} {!die()} {/if}
{include $model->loadModel('ui')->getEffectViewFile('default', 'block', 'articletree')}
