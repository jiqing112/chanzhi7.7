{if(!defined("RUN_MODE"))} {!die()} {/if}
{include TPL_ROOT . 'block/articletree.html.php'}
