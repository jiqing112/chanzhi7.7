$(document).ready(function()
{
    $('.nav-page-' + v.pageID + ':first').addClass('active');
});
