{if(!defined("RUN_MODE"))} {!die()} {/if}

