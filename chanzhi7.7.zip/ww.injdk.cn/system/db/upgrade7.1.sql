ALTER TABLE `eps_layout` CHANGE plan theme char(30) NOT NULL;
