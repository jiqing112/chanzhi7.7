ALTER TABLE `eps_oauth` Add `unionID` char(60) NOT NULL AFTER `openID`;
