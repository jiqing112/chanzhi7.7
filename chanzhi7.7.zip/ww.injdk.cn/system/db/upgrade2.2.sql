ALTER TABLE `eps_user` CHANGE `public` `public` varchar(30) NOT NULL DEFAULT '0';
